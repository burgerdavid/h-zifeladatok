﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace templomok
{
    public partial class MainWindow : Window
    {

        private string[] templomNevek = { "Nagyboldog Asszony templom 1253",
                                          "Szent György templom 1256",
                                          "Bencés Apátság 1061",
                                          "Szent Jakab apostol plébániatemplom 1208",
                                          "Péter Pál református templom 1250",
                                          "Boldogságos Szűz Mária református templom 1250",
                                          "Pannonhalmi Bencés Főapátság 1350",
                                          "Szent Demeter templom 1000",
                                          "Mária látogatása templom 1108",
                                          "Gyümolcsoltó Boldogasszony prépostsági templom 1250"};

        private string[] varosNevek = { "Bélapátfalva",
                                      "Ják",
                                      "Kaposszentjakab",
                                      "Lébény",
                                      "Lónya",
                                      "Ócsa",
                                      "Pannonhalma",
                                      "Szeged",
                                      "Tarnaszentmária",
                                      "Türje"};

        private string[] kepUtvonalak = { "Belapatfalva.jpg", 
                                          "Jak.jpg", 
                                          "Kaposszentjakab.jpg",
                                          "Lebeny.jpg",
                                          "Lonya.jpg",
                                          "Ocsa.jpg",
                                          "Pannonhalma.jpg",
                                          "Szeged.jpg",
                                          "Tarnaszentmaria.jpg",
                                          "Turje.jpg"};

        private int jelenlegiIndex = 0;
        public MainWindow()
        {
            InitializeComponent();
            BetoltAdatok(jelenlegiIndex);
        }

        private void BetoltAdatok(int index)
        {
            templomAdatok.Content = $"Név: {templomNevek[index]}\nVáros: {varosNevek[index]}";
            BitmapImage kep = new BitmapImage(new Uri(kepUtvonalak[index], UriKind.Relative));
            templomKep.Source = kep;
        }

        private void ElozoTemplom(object sender, RoutedEventArgs e)
        {
            jelenlegiIndex = (jelenlegiIndex - 1 + templomNevek.Length) % templomNevek.Length;
            BetoltAdatok(jelenlegiIndex);
        }

        private void KovetkezoTemplom(object sender, RoutedEventArgs e)
        {
            jelenlegiIndex = (jelenlegiIndex + 1) % templomNevek.Length;
            BetoltAdatok(jelenlegiIndex);
        }

    }
}
