setInterval(() => {
	datum = new Date();
	o = datum.getHours();
	p = datum.getMinutes();
	mp = datum.getSeconds();
	ora_rotation = 30 * o + p / 2;
	perc_rotation = 6 * p;
	mp_rotation = 6 * mp;

	ora.style.transform = `rotate(${ora_rotation}deg)`;
	perc.style.transform = `rotate(${perc_rotation}deg)`;
	masodperc.style.transform = `rotate(${mp_rotation}deg)`;
}, 1000);