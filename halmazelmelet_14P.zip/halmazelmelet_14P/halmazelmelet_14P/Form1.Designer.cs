﻿namespace halmazelmelet_14P
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbHalmaz = new System.Windows.Forms.ListBox();
            this.tbBeolvas = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbElemszam = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbAlsoHatar = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbFelsoHatar = new System.Windows.Forms.TextBox();
            this.tbMasikHalmaz = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnSzamossag = new System.Windows.Forms.Button();
            this.btnDisjunkt = new System.Windows.Forms.Button();
            this.btnUnio = new System.Windows.Forms.Button();
            this.btnMetszet = new System.Windows.Forms.Button();
            this.btnKulonbseg = new System.Windows.Forms.Button();
            this.btnDescartes = new System.Windows.Forms.Button();
            this.btnBeolvas = new System.Windows.Forms.Button();
            this.btnGeneral = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbHalmaz
            // 
            this.lbHalmaz.FormattingEnabled = true;
            this.lbHalmaz.Location = new System.Drawing.Point(250, 12);
            this.lbHalmaz.Name = "lbHalmaz";
            this.lbHalmaz.Size = new System.Drawing.Size(368, 199);
            this.lbHalmaz.TabIndex = 3;
            // 
            // tbBeolvas
            // 
            this.tbBeolvas.Location = new System.Drawing.Point(90, 12);
            this.tbBeolvas.Name = "tbBeolvas";
            this.tbBeolvas.Size = new System.Drawing.Size(145, 20);
            this.tbBeolvas.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Beolvasás";
            // 
            // tbElemszam
            // 
            this.tbElemszam.Location = new System.Drawing.Point(90, 38);
            this.tbElemszam.Name = "tbElemszam";
            this.tbElemszam.Size = new System.Drawing.Size(145, 20);
            this.tbElemszam.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Elemszám";
            // 
            // tbAlsoHatar
            // 
            this.tbAlsoHatar.Location = new System.Drawing.Point(142, 64);
            this.tbAlsoHatar.Name = "tbAlsoHatar";
            this.tbAlsoHatar.Size = new System.Drawing.Size(93, 20);
            this.tbAlsoHatar.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(82, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Alsó határ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(82, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Felső határ";
            // 
            // tbFelsoHatar
            // 
            this.tbFelsoHatar.Location = new System.Drawing.Point(142, 90);
            this.tbFelsoHatar.Name = "tbFelsoHatar";
            this.tbFelsoHatar.Size = new System.Drawing.Size(93, 20);
            this.tbFelsoHatar.TabIndex = 11;
            // 
            // tbMasikHalmaz
            // 
            this.tbMasikHalmaz.Location = new System.Drawing.Point(90, 128);
            this.tbMasikHalmaz.Name = "tbMasikHalmaz";
            this.tbMasikHalmaz.Size = new System.Drawing.Size(145, 20);
            this.tbMasikHalmaz.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Másik halmaz";
            // 
            // btnSzamossag
            // 
            this.btnSzamossag.Location = new System.Drawing.Point(492, 221);
            this.btnSzamossag.Name = "btnSzamossag";
            this.btnSzamossag.Size = new System.Drawing.Size(90, 47);
            this.btnSzamossag.TabIndex = 14;
            this.btnSzamossag.Text = "Számosság";
            this.btnSzamossag.UseVisualStyleBackColor = true;
            this.btnSzamossag.Click += new System.EventHandler(this.btnSzamossag_Click);
            // 
            // btnDisjunkt
            // 
            this.btnDisjunkt.Location = new System.Drawing.Point(396, 221);
            this.btnDisjunkt.Name = "btnDisjunkt";
            this.btnDisjunkt.Size = new System.Drawing.Size(90, 47);
            this.btnDisjunkt.TabIndex = 15;
            this.btnDisjunkt.Text = "Diszjunkt";
            this.btnDisjunkt.UseVisualStyleBackColor = true;
            this.btnDisjunkt.Click += new System.EventHandler(this.btnDisjunkt_Click);
            // 
            // btnUnio
            // 
            this.btnUnio.Location = new System.Drawing.Point(300, 221);
            this.btnUnio.Name = "btnUnio";
            this.btnUnio.Size = new System.Drawing.Size(90, 47);
            this.btnUnio.TabIndex = 16;
            this.btnUnio.Text = "Unio";
            this.btnUnio.UseVisualStyleBackColor = true;
            this.btnUnio.Click += new System.EventHandler(this.btnUnio_Click);
            // 
            // btnMetszet
            // 
            this.btnMetszet.Location = new System.Drawing.Point(204, 221);
            this.btnMetszet.Name = "btnMetszet";
            this.btnMetszet.Size = new System.Drawing.Size(90, 47);
            this.btnMetszet.TabIndex = 17;
            this.btnMetszet.Text = "Metszet";
            this.btnMetszet.UseVisualStyleBackColor = true;
            this.btnMetszet.Click += new System.EventHandler(this.btnMetszet_Click);
            // 
            // btnKulonbseg
            // 
            this.btnKulonbseg.Location = new System.Drawing.Point(108, 221);
            this.btnKulonbseg.Name = "btnKulonbseg";
            this.btnKulonbseg.Size = new System.Drawing.Size(90, 47);
            this.btnKulonbseg.TabIndex = 18;
            this.btnKulonbseg.Text = "Különbség";
            this.btnKulonbseg.UseVisualStyleBackColor = true;
            this.btnKulonbseg.Click += new System.EventHandler(this.btnKulonbseg_Click);
            // 
            // btnDescartes
            // 
            this.btnDescartes.Location = new System.Drawing.Point(12, 221);
            this.btnDescartes.Name = "btnDescartes";
            this.btnDescartes.Size = new System.Drawing.Size(90, 47);
            this.btnDescartes.TabIndex = 19;
            this.btnDescartes.Text = "Descartes";
            this.btnDescartes.UseVisualStyleBackColor = true;
            this.btnDescartes.Click += new System.EventHandler(this.btnDescartes_Click);
            // 
            // btnBeolvas
            // 
            this.btnBeolvas.Location = new System.Drawing.Point(145, 164);
            this.btnBeolvas.Name = "btnBeolvas";
            this.btnBeolvas.Size = new System.Drawing.Size(90, 47);
            this.btnBeolvas.TabIndex = 20;
            this.btnBeolvas.Text = "Beolvas";
            this.btnBeolvas.UseVisualStyleBackColor = true;
            this.btnBeolvas.Click += new System.EventHandler(this.btnBeolvas_Click);
            // 
            // btnGeneral
            // 
            this.btnGeneral.Location = new System.Drawing.Point(12, 164);
            this.btnGeneral.Name = "btnGeneral";
            this.btnGeneral.Size = new System.Drawing.Size(90, 47);
            this.btnGeneral.TabIndex = 21;
            this.btnGeneral.Text = "Generálás";
            this.btnGeneral.UseVisualStyleBackColor = true;
            this.btnGeneral.Click += new System.EventHandler(this.btnGeneral_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(621, 280);
            this.Controls.Add(this.btnGeneral);
            this.Controls.Add(this.btnBeolvas);
            this.Controls.Add(this.btnDescartes);
            this.Controls.Add(this.btnKulonbseg);
            this.Controls.Add(this.btnMetszet);
            this.Controls.Add(this.btnUnio);
            this.Controls.Add(this.btnDisjunkt);
            this.Controls.Add(this.btnSzamossag);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbMasikHalmaz);
            this.Controls.Add(this.tbFelsoHatar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbAlsoHatar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbElemszam);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbBeolvas);
            this.Controls.Add(this.lbHalmaz);
            this.Name = "Form1";
            this.Text = "Halmazelmélet";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox lbHalmaz;
        private System.Windows.Forms.TextBox tbBeolvas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbElemszam;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbAlsoHatar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbFelsoHatar;
        private System.Windows.Forms.TextBox tbMasikHalmaz;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnSzamossag;
        private System.Windows.Forms.Button btnDisjunkt;
        private System.Windows.Forms.Button btnUnio;
        private System.Windows.Forms.Button btnMetszet;
        private System.Windows.Forms.Button btnKulonbseg;
        private System.Windows.Forms.Button btnDescartes;
        private System.Windows.Forms.Button btnBeolvas;
        private System.Windows.Forms.Button btnGeneral;
    }
}

