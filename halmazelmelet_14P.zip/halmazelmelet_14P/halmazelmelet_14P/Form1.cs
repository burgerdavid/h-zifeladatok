﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace halmazelmelet_14P
{
    public partial class Form1 : Form
    {
        private HashSet<int> halmaz;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnBeolvas_Click(object sender, EventArgs e)
        {
            string[] adatok = tbBeolvas.Text.Split(new char[] { ' ', ',', ';' }, StringSplitOptions.RemoveEmptyEntries);

            if (IsValidHalmaz(adatok))
            {
                halmaz = new HashSet<int>(adatok.Select(int.Parse));
                FrissitListBox();
            }
            else
            {
                MessageBox.Show("Hibás adatformátum. Adj meg érvényes egész számokat szóközzel vagy vesszővel elválasztva!");
            }
        }

        private bool IsValidHalmaz(string[] adatok)
        {
            return adatok.All(szam => int.TryParse(szam, out _));
        }

        private void btnGeneral_Click(object sender, EventArgs e)
        {
            if (int.TryParse(tbElemszam.Text, out int elemszam) &&
                int.TryParse(tbAlsoHatar.Text, out int alsoHatar) &&
                int.TryParse(tbFelsoHatar.Text, out int felsoHatar))
            {
                if (elemszam >= 0 && alsoHatar <= felsoHatar)
                {
                    Random random = new Random();
                    halmaz = new HashSet<int>(Enumerable.Range(alsoHatar, felsoHatar - alsoHatar + 1).OrderBy(x => random.Next()).Take(elemszam));
                    FrissitListBox();
                }
                else
                {
                    MessageBox.Show("Hibás adatok. Az elemszám legyen nemnegatív, és az alsó határ kisebb vagy egyenlő a felső határral!");
                }
            }
            else
            {
                MessageBox.Show("Hibás adatok. Az elemszám, az alsó határ és a felső határ érvényes egész számok legyenek!");
            }
        }

        private void FrissitListBox()
        {
            lbHalmaz.Items.Clear();
            foreach (var elem in halmaz)
            {
                lbHalmaz.Items.Add(elem);
            }
        }

        private void btnSzamossag_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"A halmaz számossága: {halmaz.Count}");
        }

        private void btnDisjunkt_Click(object sender, EventArgs e)
        {
            HashSet<int> masikHalmaz = BeolvasMasikHalmaz();
            if (masikHalmaz != null)
            {
                MessageBox.Show(halmaz.Overlaps(masikHalmaz) ? "A két halmaz nem diszjunkt." : "A két halmaz diszjunkt.");
            }
        }

        private HashSet<int> BeolvasMasikHalmaz()
        {
            string[] adatok = tbMasikHalmaz.Text.Split(new char[] { ' ', ',', ';' }, StringSplitOptions.RemoveEmptyEntries);

            if (IsValidHalmaz(adatok))
            {
                return new HashSet<int>(adatok.Select(int.Parse));
            }
            else
            {
                MessageBox.Show("Hibás adatformátum. Adj meg érvényes egész számokat szóközzel vagy vesszővel elválasztva!");
                return null;
            }
        }

        private void btnUnio_Click(object sender, EventArgs e)
        {
            HashSet<int> masikHalmaz = BeolvasMasikHalmaz();
            if (masikHalmaz != null)
            {
                var unioHalmaz = new HashSet<int>(halmaz.Union(masikHalmaz));
                MessageBox.Show($"Az unió halmaz: {string.Join(", ", unioHalmaz)}");
            }
        }

        private void btnMetszet_Click(object sender, EventArgs e)
        {
            HashSet<int> masikHalmaz = BeolvasMasikHalmaz();
            if (masikHalmaz != null)
            {
                var metszetHalmaz = new HashSet<int>(halmaz.Intersect(masikHalmaz));
                MessageBox.Show($"A metszet halmaz: {string.Join(", ", metszetHalmaz)}");
            }
        }

        private void btnKulonbseg_Click(object sender, EventArgs e)
        {
            HashSet<int> masikHalmaz = BeolvasMasikHalmaz();
            if (masikHalmaz != null)
            {
                var kulonbsegHalmaz = new HashSet<int>(halmaz.Except(masikHalmaz));
                MessageBox.Show($"A különbség halmaz: {string.Join(", ", kulonbsegHalmaz)}");
            }
        }

        private void btnDescartes_Click(object sender, EventArgs e)
        {
            HashSet<int> masikHalmaz = BeolvasMasikHalmaz();
            if (masikHalmaz != null)
            {
                var descartesHalmaz = new HashSet<string>(
                    from elem1 in halmaz
                    from elem2 in masikHalmaz
                    select $"({elem1}, {elem2})"
                );

                MessageBox.Show($"A Descartes-féle szorzathalmaz: {string.Join(", ", descartesHalmaz)}");
            }
        }
    }
}
