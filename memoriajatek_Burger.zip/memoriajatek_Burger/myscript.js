let cards = [];
let selectedCards = [];
let pairsFound = 0;
let isWaiting = false;
let startTime;
let endTime;

function startGame(rows, columns) {
    const boardSize = rows * columns;
    cards = generateCards(boardSize);
    shuffleCards(cards);
    renderBoard(rows, columns);
    resetGame();
}

function generateCards(cardCount) {
  const symbols = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24'];
  let cardPairs = symbols.slice(0, cardCount / 2);
  cardPairs = cardPairs.concat(cardPairs);
  return cardPairs.map(symbol => ({ symbol, isMatched: false }));
}

function shuffleCards(cards) {
  for (let i = cards.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [cards[i], cards[j]] = [cards[j], cards[i]];
  }
}

function renderBoard(rows, columns) {
  const gameBoard = document.getElementById('game-board');
  gameBoard.innerHTML = '';
  gameBoard.style.gridTemplateColumns = `repeat(${columns}, 100px)`;

  for (let i = 0; i < cards.length; i++) {
    const card = document.createElement('div');
    card.classList.add('card');
    card.dataset.index = i;
    card.textContent = '?';
    card.addEventListener('click', onCardClick);
    gameBoard.appendChild(card);
  }
}

function onCardClick(event) {
    if (isWaiting) return;

    const selectedCardIndex = event.target.dataset.index;
    const selectedCard = cards[selectedCardIndex];

    if (selectedCard.isMatched) return;

    event.target.textContent = selectedCard.symbol;
    selectedCards.push({ index: selectedCardIndex, symbol: selectedCard.symbol });

    if (selectedCards.length === 1) {
      startTime = new Date().getTime();
    } else if (selectedCards.length === 2) {
      endTime = new Date().getTime();
      isWaiting = true;
      setTimeout(checkMatch, 1000);
    }
}

function checkMatch() {
  const [card1, card2] = selectedCards;

  if (card1.symbol === card2.symbol) {
    cards[card1.index].isMatched = true;
    cards[card2.index].isMatched = true;
    pairsFound++;

    if (pairsFound === cards.length / 2) {
      endGame();
    }
  } else {
    hideCards([card1.index, card2.index]);
  }

  selectedCards = [];
  isWaiting = false;
}

function hideCards(indices) {
  indices.forEach(index => {
    const cardElement = document.querySelector(`[data-index="${index}"]`);
    cardElement.textContent = '?';
  });
}

function endGame() {
    calculateScore();
    alert('Gratulálok, győztél! Pontszám: ' + calculateScore());
    addToToplist(calculateScore());
    resetGame();
}

function calculateScore() {
    const timeDifference = (endTime - startTime) / 1000;
    let score = 1000;

    if (timeDifference <= 3) {
      score -= 0;
    } else if (timeDifference <= 10) {
      score -= 10;
    } else {
      score -= 20;
    }
    return Math.max(score, 0);
}

function addToToplist(score) {
    const playerName = prompt('Add meg a neved a toplistához:');
    const timeDifference = ((endTime - startTime) / 1000) * 60;
    let timeFormatted;
    if (timeDifference >= 60) {
        const minutes = Math.floor(timeDifference / 60);
        const seconds = (timeDifference % 60).toFixed(1);
        timeFormatted = `${minutes} perc ${seconds} mp`;
    } else {
        timeFormatted = timeDifference.toFixed(1) + ' mp';
    }
    const toplistEntry = { name: playerName, score: score, time: timeDifference };
    let toplist = JSON.parse(localStorage.getItem('toplist')) || [];
    toplist.push(toplistEntry);
    toplist.sort((a, b) => a.score - b.score || a.time - b.time);
    toplist = toplist.slice(0, 20);

    localStorage.setItem('toplist', JSON.stringify(toplist));
  }

function resetGame() {
  pairsFound = 0;
  isWaiting = false;
}

function showToplist() {
    const toplistContainer = document.getElementById('toplist-container');
    const toplistElement = document.getElementById('toplist');
    toplistElement.innerHTML = '';

    const toplist = JSON.parse(localStorage.getItem('toplist')) || [];

    if (toplist.length === 0) {
      toplistContainer.style.display = 'none';
      return;
    }

    toplistContainer.style.display = 'block';

    toplist.sort((a, b) => a.score - b.score || a.time - b.time);

    toplist.forEach(entry => {
      const listItem = document.createElement('li');
      listItem.textContent = `${entry.name} - ${entry.score} pont - ${entry.time.toFixed(3)} mp`;
      toplistElement.appendChild(listItem);
    });
}


function resetToplist() {
    localStorage.removeItem('toplist');
    showToplist();
}

showToplist();