﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace szinvalaszto
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MenuPontok();
        }

        static void MenuPontok()
        {
            Console.WriteLine("Menüpontok");
            Console.WriteLine("1. Színek megadása -m");
            Console.WriteLine("2. Gui inditása -g");
            Console.WriteLine("3. Kilépes -k");

            Console.Write("Kerem valasszon egy menupontot: ");
            char valasztas = Console.ReadKey().KeyChar;
            Console.WriteLine();

            switch (valasztas)
            {
                case 'm':
                    SzinekMegadasa();
                    break;
                case 'g':
                    GuiInditas();
                    break;
                case 'k':
                    break;
                default:
                    Console.WriteLine("Érvenytelen választás.");
                    break;
            }
        }

        static void SzinekMegadasa()
        {
            Console.WriteLine("Színek megadása menüpont");

            string[] alapSzinek = { "fekete", "fehér", "kék", "magenta", "cyan", "zöld", "sárga" };
            string[] valasztottSzinek = new string[5];

            Console.WriteLine("Kérem válasszon 5 színt az alábbiak közül:");
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"Lehetséges színek: {string.Join(", ", alapSzinek)}");

                Console.ForegroundColor = ConsoleColor.Gray;
                Console.Write($"{i + 1}. szín: ");


                string valasztottSzin = Console.ReadLine();

                if (i == 4)
                {
                    valasztottSzinek[i] = valasztottSzin;
                    KiirasFajlba(valasztottSzinek);
                    Console.WriteLine("Sikeresen kiírta a színeket a txt fájlba.");
                    Console.WriteLine();
                    MenuPontok();
                    return;
                }
                else
                {
                    SetConsoleColor(valasztottSzin);
                    valasztottSzinek[i] = valasztottSzin;
                }
                Console.WriteLine($"Adjon meg egy következő színt ({i + 2}.): ");
                Console.ForegroundColor = ConsoleColor.Gray;
            }

            Console.WriteLine("Választott színek beállitva.");
        }

        static void SetConsoleColor(string szin)
        {
            switch (szin.ToLower())
            {
                case "fekete":
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.BackgroundColor = ConsoleColor.White;
                    break;
                case "fehér":
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.Black;
                    break;
                case "kék":
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.BackgroundColor = ConsoleColor.Black;
                    break;
                case "magenta":
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.BackgroundColor = ConsoleColor.Black;
                    break;
                case "cyan":
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.BackgroundColor = ConsoleColor.Black;
                    break;
                case "zöld":
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.BackgroundColor = ConsoleColor.Black;
                    break;
                case "sárga":
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.BackgroundColor = ConsoleColor.Black;
                    break;
                case "piros":
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.BackgroundColor = ConsoleColor.Black;
                    break;
                default:
                    Console.WriteLine("Nincs ilyen szín, kérem válasszon egy másikat.");
                    break;
            }
        }

        static void KiirasFajlba(string[] valasztottSzinek)
        {
            string filePath = "valasztott_szinek.txt";

            try
            {
                File.WriteAllLines(filePath, valasztottSzinek);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba törtent a fájl irása közben: {ex.Message}");
            }
        }

        static void GuiInditas()
        {
            string alkalmazasEleresiUt = @"D:\Burger_Dávid_14P\SzinozonJatek_Burger\SzinozonJatek_Burger\bin\Debug\SzinezosJatek.exe";

            try
            {
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = alkalmazasEleresiUt;
                psi.UseShellExecute = false;
                psi.RedirectStandardInput = true;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;

                Process process = new Process();
                process.StartInfo = psi;
                process.EnableRaisingEvents = true;
                process.Start();
                process.WaitForExit();

                Console.WriteLine("A másik alkalmazás bezáródott.");
                MenuPontok();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba történt az alkalmazás indítása közben: {ex.Message}");
            }
        }

        static void Kilépés()
        {
            Environment.Exit(0);
        }
    }
}
