﻿namespace torpedojatek_Burger
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.jatekos1Panel = new System.Windows.Forms.Panel();
            this.jatekos2Panel = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // jatekos1Panel
            // 
            this.jatekos1Panel.Location = new System.Drawing.Point(34, 42);
            this.jatekos1Panel.Name = "jatekos1Panel";
            this.jatekos1Panel.Size = new System.Drawing.Size(392, 338);
            this.jatekos1Panel.TabIndex = 0;
            // 
            // jatekos2Panel
            // 
            this.jatekos2Panel.Location = new System.Drawing.Point(463, 42);
            this.jatekos2Panel.Name = "jatekos2Panel";
            this.jatekos2Panel.Size = new System.Drawing.Size(380, 338);
            this.jatekos2Panel.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(896, 461);
            this.Controls.Add(this.jatekos2Panel);
            this.Controls.Add(this.jatekos1Panel);
            this.Name = "Form1";
            this.Text = "Torpedójáték";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel jatekos1Panel;
        private System.Windows.Forms.Panel jatekos2Panel;
    }
}

