﻿namespace torpedojatek_Burger
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.player1Panel = new System.Windows.Forms.Panel();
            this.player2Panel = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // player1Panel
            // 
            this.player1Panel.Location = new System.Drawing.Point(34, 42);
            this.player1Panel.Name = "player1Panel";
            this.player1Panel.Size = new System.Drawing.Size(392, 338);
            this.player1Panel.TabIndex = 0;
            // 
            // player2Panel
            // 
            this.player2Panel.Location = new System.Drawing.Point(463, 42);
            this.player2Panel.Name = "player2Panel";
            this.player2Panel.Size = new System.Drawing.Size(380, 338);
            this.player2Panel.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(896, 461);
            this.Controls.Add(this.player2Panel);
            this.Controls.Add(this.player1Panel);
            this.Name = "Form1";
            this.Text = "Torpedójáték";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel player1Panel;
        private System.Windows.Forms.Panel player2Panel;
    }
}

