﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace torpedojatek_Burger
{
    public partial class Form1 : Form
    {
        private const int BOARD_SIZE = 10;
        private const int CELL_SIZE = 30;

        private Panel[,] player1Board;
        private Panel[,] player2Board;

        private char[,] player1Ships = new char[BOARD_SIZE, BOARD_SIZE];
        private char[,] player2Ships = new char[BOARD_SIZE, BOARD_SIZE];

        private bool player1Turn = true;
        private bool gameOver = false;

        public Form1()
        {
            InitializeComponent();
            InitializeBoards();
            InitializeShips();
        }

        private void InitializeBoards()
        {
            player1Board = new Panel[BOARD_SIZE, BOARD_SIZE];
            player2Board = new Panel[BOARD_SIZE, BOARD_SIZE];

            for (int i = 0; i < BOARD_SIZE; i++)
            {
                Label colLabel1 = new Label();
                colLabel1.Text = (i + 1).ToString();
                colLabel1.Size = new Size(CELL_SIZE, CELL_SIZE);
                colLabel1.Location = new Point(CELL_SIZE * (i + 1), 0);
                colLabel1.TextAlign = ContentAlignment.MiddleCenter;
                player1Panel.Controls.Add(colLabel1);

                Label rowLabel1 = new Label();
                rowLabel1.Text = ((char)('A' + i)).ToString();
                rowLabel1.Size = new Size(CELL_SIZE, CELL_SIZE);
                rowLabel1.Location = new Point(0, CELL_SIZE * (i + 1));
                rowLabel1.TextAlign = ContentAlignment.MiddleCenter;
                player1Panel.Controls.Add(rowLabel1);

                Label colLabel2 = new Label();
                colLabel2.Text = (i + 1).ToString();
                colLabel2.Size = new Size(CELL_SIZE, CELL_SIZE);
                colLabel2.Location = new Point(CELL_SIZE * (i + 1), 0);
                colLabel2.TextAlign = ContentAlignment.MiddleCenter;
                player2Panel.Controls.Add(colLabel2);

                Label rowLabel2 = new Label();
                rowLabel2.Text = ((char)('A' + i)).ToString();
                rowLabel2.Size = new Size(CELL_SIZE, CELL_SIZE);
                rowLabel2.Location = new Point(0, CELL_SIZE * (i + 1));
                rowLabel2.TextAlign = ContentAlignment.MiddleCenter;
                player2Panel.Controls.Add(rowLabel2);
            }

            for (int i = 0; i < BOARD_SIZE; i++)
            {
                for (int j = 0; j < BOARD_SIZE; j++)
                {
                    Panel panel1 = new Panel();
                    panel1.Size = new Size(CELL_SIZE, CELL_SIZE);
                    panel1.Location = new Point((j + 1) * CELL_SIZE, (i + 1) * CELL_SIZE);
                    panel1.BorderStyle = BorderStyle.FixedSingle;
                    panel1.BackColor = Color.LightBlue;
                    panel1.Click += Player1Board_Click;
                    panel1.Tag = i * BOARD_SIZE + j;
                    player1Panel.Controls.Add(panel1);
                    player1Board[i, j] = panel1;

                    Panel panel2 = new Panel();
                    panel2.Size = new Size(CELL_SIZE, CELL_SIZE);
                    panel2.Location = new Point((j + 1) * CELL_SIZE, (i + 1) * CELL_SIZE);
                    panel2.BorderStyle = BorderStyle.FixedSingle;
                    panel2.BackColor = Color.LightBlue;
                    panel2.Click += Player2Board_Click;
                    panel2.Tag = i * BOARD_SIZE + j;
                    player2Panel.Controls.Add(panel2);
                    player2Board[i, j] = panel2;
                }
            }
        }

        private void InitializeShips()
        {
            int[] shipSizes = { 5, 4, 3, 2, 1 };

            Random random = new Random();

            foreach (int size in shipSizes)
            {
                PlaceShip(player1Ships, size, random);

                PlaceShip(player2Ships, size, random);
            }
        }

        private void PlaceShip(char[,] board, int size, Random random)
        {
            int x, y, orientation;
            do
            {
                x = random.Next(0, BOARD_SIZE);
                y = random.Next(0, BOARD_SIZE);
                orientation = random.Next(0, 2);
            } while (!IsValidShipPosition(board, x, y, size, orientation));

            if (orientation == 0)
            {
                for (int i = 0; i < size; i++)
                {
                    board[x, y + i] = 'S';
                }
            }
            else
            {
                for (int i = 0; i < size; i++)
                {
                    board[x + i, y] = 'S';
                }
            }
        }

        private bool IsValidShipPosition(char[,] board, int x, int y, int size, int orientation)
        {

            if (orientation == 0 && y + size <= BOARD_SIZE)
            {
                for (int i = 0; i < size; i++)
                {
                    if (board[x, y + i] != '\0')
                        return false;
                }

                for (int i = Math.Max(0, x - 1); i <= Math.Min(BOARD_SIZE - 1, x + 1); i++)
                {
                    for (int j = Math.Max(0, y - 1); j <= Math.Min(BOARD_SIZE - 1, y + size); j++)
                    {
                        if (board[i, j] != '\0')
                            return false;
                    }
                }

                return true;
            }
            else if (orientation == 1 && x + size <= BOARD_SIZE)
            {
                for (int i = 0; i < size; i++)
                {
                    if (board[x + i, y] != '\0')
                        return false;
                }

                for (int i = Math.Max(0, x - 1); i <= Math.Min(BOARD_SIZE - 1, x + size); i++)
                {
                    for (int j = Math.Max(0, y - 1); j <= Math.Min(BOARD_SIZE - 1, y + 1); j++)
                    {
                        if (board[i, j] != '\0')
                            return false;
                    }
                }

                return true;
            }
            return false;
        }

        private void PlaceShip(char[,] board, int x1, int y1, int x2, int y2)
        {
            if (x1 == x2)
            {
                for (int j = Math.Min(y1, y2); j <= Math.Max(y1, y2); j++)
                {
                    board[x1, j] = 'S';
                    if (x1 > 0)
                        board[x1 - 1, j] = 'O';
                    if (x1 < BOARD_SIZE - 1)
                        board[x1 + 1, j] = 'O';
                    if (j > 0)
                        board[x1, j - 1] = 'O';
                    if (j < BOARD_SIZE - 1)
                        board[x1, j + 1] = 'O';
                }
            }
            else if (y1 == y2)
            {
                for (int i = Math.Min(x1, x2); i <= Math.Max(x1, x2); i++)
                {
                    board[i, y1] = 'S';
                    if (y1 > 0)
                        board[i, y1 - 1] = 'O';
                    if (y1 < BOARD_SIZE - 1)
                        board[i, y1 + 1] = 'O';
                    if (i > 0)
                        board[i - 1, y1] = 'O';
                    if (i < BOARD_SIZE - 1)
                        board[i + 1, y1] = 'O';
                }
            }
        }

        private void Player1Board_Click(object sender, EventArgs e)
        {
            if (gameOver || !player1Turn)
                return;

            Panel panel = (Panel)sender;
            int cellIndex = (int)panel.Tag;
            int row = cellIndex / BOARD_SIZE;
            int col = cellIndex % BOARD_SIZE;

            if (player2Ships[row, col] == 'S')
            {
                panel.BackColor = Color.Red;
                player2Ships[row, col] = 'X';
                panel.Click -= Player1Board_Click;
                CheckGameOver(player2Ships);
            }
            else if (player2Ships[row, col] != 'X')
            {
                panel.BackColor = Color.Gray;
            }

            player1Turn = false;
        }

        private void Player2Board_Click(object sender, EventArgs e)
        {
            if (gameOver || player1Turn)
                return;

            Panel panel = (Panel)sender;
            int cellIndex = (int)panel.Tag;
            int row = cellIndex / BOARD_SIZE;
            int col = cellIndex % BOARD_SIZE;

            if (player1Ships[row, col] == 'S')
            {
                panel.BackColor = Color.Red;
                player1Ships[row, col] = 'X';
                panel.Click -= Player2Board_Click;
                CheckGameOver(player1Ships);
            }
            else if (player1Ships[row, col] != 'X')
            {
                panel.BackColor = Color.Gray;
            }

            player1Turn = true;
        }

        private enum Jatekos
        {
            Jatekos1,
            Jatekos2
        }

        private void CheckGameOver(char[,] ships)
        {

            foreach (char c in ships)
            {
                if (c == 'S')
                    return;
            }

            gameOver = true;
            Jatekos winner = player1Turn ? Jatekos.Jatekos2 : Jatekos.Jatekos1;
            DialogResult result = MessageBox.Show($"Játék vége! {winner} nyert! Szeretnél új játékot kezdeni?", "Játék vége!", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                ResetGame();
            }
            else
            {
                Application.Exit();
            }
        }

        private void ResetGame()
        {
            player1Panel.Controls.Clear();
            player2Panel.Controls.Clear();
            gameOver = false;

            InitializeBoards();
            InitializeShips();

            player1Turn = true;
        }
    }
}
