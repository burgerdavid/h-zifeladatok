﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace torpedojatek_Burger
{
    public partial class Form1 : Form
    {
        private const int TABLA_MERET = 10;
        private const int CELLAMERET = 30;

        private Panel[,] jatekos1Tabla;
        private Panel[,] jatekos2Tabla;

        private char[,] jatekos1Hajok = new char[TABLA_MERET, TABLA_MERET];
        private char[,] jatekos2Hajok = new char[TABLA_MERET, TABLA_MERET];

        private bool jatekos1Kor = true;
        private bool jatekVege = false;

        public Form1()
        {
            InitializeComponent();
            TablakInicializalasa();
            HajokInicializalasa();
        }

        private void TablakInicializalasa()
        {
            jatekos1Tabla = new Panel[TABLA_MERET, TABLA_MERET];
            jatekos2Tabla = new Panel[TABLA_MERET, TABLA_MERET];

            for (int i = 0; i < TABLA_MERET; i++)
            {
                Label colLabel1 = new Label();
                colLabel1.Text = (i + 1).ToString();
                colLabel1.Size = new Size(CELLAMERET, CELLAMERET);
                colLabel1.Location = new Point(CELLAMERET * (i + 1), 0);
                colLabel1.TextAlign = ContentAlignment.MiddleCenter;
                jatekos1Panel.Controls.Add(colLabel1);

                Label rowLabel1 = new Label();
                rowLabel1.Text = ((char)('A' + i)).ToString();
                rowLabel1.Size = new Size(CELLAMERET, CELLAMERET);
                rowLabel1.Location = new Point(0, CELLAMERET * (i + 1));
                rowLabel1.TextAlign = ContentAlignment.MiddleCenter;
                jatekos1Panel.Controls.Add(rowLabel1);

                Label colLabel2 = new Label();
                colLabel2.Text = (i + 1).ToString();
                colLabel2.Size = new Size(CELLAMERET, CELLAMERET);
                colLabel2.Location = new Point(CELLAMERET * (i + 1), 0);
                colLabel2.TextAlign = ContentAlignment.MiddleCenter;
                jatekos2Panel.Controls.Add(colLabel2);

                Label rowLabel2 = new Label();
                rowLabel2.Text = ((char)('A' + i)).ToString();
                rowLabel2.Size = new Size(CELLAMERET, CELLAMERET);
                rowLabel2.Location = new Point(0, CELLAMERET * (i + 1));
                rowLabel2.TextAlign = ContentAlignment.MiddleCenter;
                jatekos2Panel.Controls.Add(rowLabel2);
            }

            for (int i = 0; i < TABLA_MERET; i++)
            {
                for (int j = 0; j < TABLA_MERET; j++)
                {
                    Panel panel1 = new Panel();
                    panel1.Size = new Size(CELLAMERET, CELLAMERET);
                    panel1.Location = new Point((j + 1) * CELLAMERET, (i + 1) * CELLAMERET);
                    panel1.BorderStyle = BorderStyle.FixedSingle;
                    panel1.BackColor = Color.LightBlue;
                    panel1.Click += Jatekos1Tabla_Click;
                    panel1.Tag = i * TABLA_MERET + j;
                    jatekos1Panel.Controls.Add(panel1);
                    jatekos1Tabla[i, j] = panel1;

                    Panel panel2 = new Panel();
                    panel2.Size = new Size(CELLAMERET, CELLAMERET);
                    panel2.Location = new Point((j + 1) * CELLAMERET, (i + 1) * CELLAMERET);
                    panel2.BorderStyle = BorderStyle.FixedSingle;
                    panel2.BackColor = Color.LightBlue;
                    panel2.Click += Jatekos2Tabla_Click;
                    panel2.Tag = i * TABLA_MERET + j;
                    jatekos2Panel.Controls.Add(panel2);
                    jatekos2Tabla[i, j] = panel2;
                }
            }
        }

        private void HajokInicializalasa()
        {
            int[] hajoMeretek = { 5, 4, 3, 2, 1 };

            Random random = new Random();

            foreach (int meret in hajoMeretek)
            {
                HajoElhelyezese(jatekos1Hajok, meret, random);

                HajoElhelyezese(jatekos2Hajok, meret, random);
            }
        }

        private void HajoElhelyezese(char[,] tabla, int meret, Random random)
        {
            int x, y, elhelyezes;
            do
            {
                x = random.Next(0, TABLA_MERET);
                y = random.Next(0, TABLA_MERET);
                elhelyezes = random.Next(0, 2);
            } while (!MegfeleloHely(tabla, x, y, meret, elhelyezes));

            if (elhelyezes == 0)
            {
                for (int i = 0; i < meret; i++)
                {
                    tabla[x, y + i] = 'H';
                }
            }
            else
            {
                for (int i = 0; i < meret; i++)
                {
                    tabla[x + i, y] = 'H';
                }
            }
        }

        private bool MegfeleloHely(char[,] tabla, int x, int y, int meret, int elhelyezes)
        {

            if (elhelyezes == 0 && y + meret <= TABLA_MERET)
            {
                for (int i = 0; i < meret; i++)
                {
                    if (tabla[x, y + i] != '\0')
                        return false;
                }

                for (int i = Math.Max(0, x - 1); i <= Math.Min(TABLA_MERET - 1, x + 1); i++)
                {
                    for (int j = Math.Max(0, y - 1); j <= Math.Min(TABLA_MERET - 1, y + meret); j++)
                    {
                        if (tabla[i, j] != '\0')
                            return false;
                    }
                }

                return true;
            }
            else if (elhelyezes == 1 && x + meret <= TABLA_MERET)
            {
                for (int i = 0; i < meret; i++)
                {
                    if (tabla[x + i, y] != '\0')
                        return false;
                }

                for (int i = Math.Max(0, x - 1); i <= Math.Min(TABLA_MERET - 1, x + meret); i++)
                {
                    for (int j = Math.Max(0, y - 1); j <= Math.Min(TABLA_MERET - 1, y + 1); j++)
                    {
                        if (tabla[i, j] != '\0')
                            return false;
                    }
                }

                return true;
            }
            return false;
        }

        private void HajoElhelyezese(char[,] tabla, int x1, int y1, int x2, int y2)
        {
            if (x1 == x2)
            {
                for (int j = Math.Min(y1, y2); j <= Math.Max(y1, y2); j++)
                {
                    tabla[x1, j] = 'H';
                    if (x1 > 0)
                        tabla[x1 - 1, j] = 'O';
                    if (x1 < TABLA_MERET - 1)
                        tabla[x1 + 1, j] = 'O';
                    if (j > 0)
                        tabla[x1, j - 1] = 'O';
                    if (j < TABLA_MERET - 1)
                        tabla[x1, j + 1] = 'O';
                }
            }
            else if (y1 == y2)
            {
                for (int i = Math.Min(x1, x2); i <= Math.Max(x1, x2); i++)
                {
                    tabla[i, y1] = 'H';
                    if (y1 > 0)
                        tabla[i, y1 - 1] = 'O';
                    if (y1 < TABLA_MERET - 1)
                        tabla[i, y1 + 1] = 'O';
                    if (i > 0)
                        tabla[i - 1, y1] = 'O';
                    if (i < TABLA_MERET - 1)
                        tabla[i + 1, y1] = 'O';
                }
            }
        }

        private void Jatekos1Tabla_Click(object sender, EventArgs e)
        {
            if (jatekVege || !jatekos1Kor)
                return;

            Panel panel = (Panel)sender;
            int cellaIndex = (int)panel.Tag;
            int sor = cellaIndex / TABLA_MERET;
            int oszlop = cellaIndex % TABLA_MERET;

            if (jatekos2Hajok[sor, oszlop] == 'H')
            {
                panel.BackColor = Color.Red;
                jatekos2Hajok[sor, oszlop] = 'T';
                panel.Click -= Jatekos1Tabla_Click;
                JatekVegeEllenorzes(jatekos2Hajok);
            }
            else if (jatekos2Hajok[sor, oszlop] != 'T')
            {
                panel.BackColor = Color.Gray;
            }

            jatekos1Kor = false;
        }

        private void Jatekos2Tabla_Click(object sender, EventArgs e)
        {
            if (jatekVege || jatekos1Kor)
                return;

            Panel panel = (Panel)sender;
            int cellaIndex = (int)panel.Tag;
            int sor = cellaIndex / TABLA_MERET;
            int oszlop = cellaIndex % TABLA_MERET;

            if (jatekos1Hajok[sor, oszlop] == 'H')
            {
                panel.BackColor = Color.Red;
                jatekos1Hajok[sor, oszlop] = 'T';
                panel.Click -= Jatekos2Tabla_Click;
                JatekVegeEllenorzes(jatekos1Hajok);
            }
            else if (jatekos1Hajok[sor, oszlop] != 'T')
            {
                panel.BackColor = Color.Gray;
            }

            jatekos1Kor = true;
        }

        private enum Jatekos
        {
            Jatekos1,
            Jatekos2
        }

        private void JatekVegeEllenorzes(char[,] hajok)
        {

            foreach (char c in hajok)
            {
                if (c == 'H')
                    return;
            }

            jatekVege = true;
            Jatekos gyoztes = jatekos1Kor ? Jatekos.Jatekos2 : Jatekos.Jatekos1;
            DialogResult eredmeny = MessageBox.Show($"Játék vége! {gyoztes} nyert! Szeretnél új játékot kezdeni?", "Játék vége!", MessageBoxButtons.YesNo);
            if (eredmeny == DialogResult.Yes)
            {
                JatekUjrainditasa();
            }
            else
            {
                Application.Exit();
            }
        }

        private void JatekUjrainditasa()
        {
            jatekos1Panel.Controls.Clear();
            jatekos2Panel.Controls.Clear();
            jatekVege = false;

            TablakInicializalasa();
            HajokInicializalasa();

            jatekos1Kor = true;
        }
    }
}
